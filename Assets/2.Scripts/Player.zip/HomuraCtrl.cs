﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//先暂时不继承
public class HomuraCtrl : MonoBehaviour
{
    [Space(20)]
    [Header("还依靠别人吗")]
    public bool DontRelyOnOthers = true;
}
