﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//先暂时不继承
public class KyokoCtrl:MonoBehaviour
{

}
